# Adafruit Raspberry Pi Finder

This package is an atom-shell app, and is not useful outside of that context. Please
visit the [Adafruit Pi Finder](https://github.com/adafruit/Adafruit-Pi-Finder) repo for
more information.

## TODO: Dev Info

How to test changes:

```console
$ npm install -g electron-prebuilt
$ npm install
$ electron test
```
